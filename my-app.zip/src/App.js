import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import CourseDetail from './pages/CourseDetail'
import CourseDetailsScreen from './pages/CourseDetailsScreen';
import UserDashboard from './pages/UserDashboard';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<CourseDetail />} />
        <Route path="/coursedetailscreen" element={<CourseDetailsScreen />} />
        <Route path="/userdashboard" element={<UserDashboard />} />
      </Routes>
    </Router>
  );
};

export default App;