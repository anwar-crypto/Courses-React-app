import React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom"

const DummyAPIData = [
    { id: 1, name: 'Course 1', details: 'Details of Course 1' },
    { id: 2, name: 'Course 2', details: 'Details of Course 2' },
    // Add more dummy data as needed
];

const Coursedetails = () => {
    const [courses, setCourses] = useState(DummyAPIData);
    const [filteredCourses, setFilteredCourses] = useState(courses);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        // Filter courses based on the search term
        const filtered = courses.filter(course =>
            course.name.toLowerCase().includes(searchTerm.toLowerCase())
        );
        setFilteredCourses(filtered);
    }, [searchTerm, courses]);

    const handleCourseClick = courseId => {
        // Navigate to the details page of the selected course
        // You can use React Router or any other navigation method here
        console.log(`Navigating to details page of course ${courseId}`);
    };

    return (
        <div>
            <input
                type="text"
                placeholder="Search courses..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
            />

            <Link to="/coursedetailscreen">
                <ul style={{ listStyleType: 'none', padding: 0 }}>
                    {filteredCourses.map(course => (
                        <li key={course.id} onClick={() => handleCourseClick(course.id)}>
                            {course.name}
                        </li>
                    ))}
                </ul>
            </Link>
        </div>
    );
};

export default Coursedetails;