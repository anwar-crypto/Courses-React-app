import React from 'react';

// Sample course model for reference
const sampleCourse = {
    name: 'Sample Course',
    instructor: 'John Doe',
    description: 'This is a sample course description.',
    enrollmentStatus: 'Open',
    duration: '8 weeks',
    schedule: 'MWF 10:00 AM - 12:00 PM',
    location: 'Online',
    prerequisites: ['Prerequisite 1', 'Prerequisite 2'],
    syllabus: 'Course syllabus content goes here.',
};

const CourseDetailsScreen = () => {
    return (
        <div>
            <h2>{sampleCourse.name}</h2>
            <p>Instructor: {sampleCourse.instructor}</p>
            <p>Description: {sampleCourse.description}</p>
            <p>Enrollment Status: {sampleCourse.enrollmentStatus}</p>
            <p>Duration: {sampleCourse.duration}</p>
            <p>Schedule: {sampleCourse.schedule}</p>
            <p>Location: {sampleCourse.location}</p>
            <p>Pre-requisites: {sampleCourse.prerequisites.join(', ')}</p>

            <details>
                <summary>Syllabus</summary>
                <p>{sampleCourse.syllabus}</p>
            </details>
        </div >
    );
};

export default CourseDetailsScreen;