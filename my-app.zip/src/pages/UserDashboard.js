import React, { useState } from 'react';

// Sample enrolled courses data
const enrolledCoursesData = [
    {
        id: 1,
        name: 'Course 1',
        instructor: 'John Doe',
        thumbnail: 'course1-thumbnail.jpg',
        dueDate: '2024-03-01',
        progress: 30,
        completed: false,
    },
    {
        id: 2,
        name: 'Course 2',
        instructor: 'Jane Smith',
        thumbnail: 'course2-thumbnail.jpg',
        dueDate: '2024-03-15',
        progress: 50,
        completed: false,
    },
    // Add more enrolled courses as needed
];

const UserDashboard = () => {
    const [enrolledCourses, setEnrolledCourses] = useState(enrolledCoursesData);

    const handleMarkAsCompleted = courseId => {
        // Update the completed status of the selected course
        const updatedCourses = enrolledCourses.map(course =>
            course.id === courseId ? { ...course, completed: true } : course
        );
        setEnrolledCourses(updatedCourses);
    };

    return (
        <div>
            <h2>Your Enrolled Courses</h2>
            <ul style={{ listStyleType: 'none', padding: 0 }}>
                {enrolledCourses.map(course => (
                    <li key={course.id} style={{ marginBottom: '20px' }}>
                        <img src={course.thumbnail} alt={`Thumbnail for ${course.name}`} style={{ maxWidth: '100px', maxHeight: '100px', marginRight: '20px' }} />
                        <div style={{ display: 'inline-block', verticalAlign: 'top' }}>
                            <h3> {course.name}</h3>
                            <p>Instructor: {course.instructor}</p>
                            <p>Due Date: {course.dueDate}</p>
                            <p>Progress: {course.progress}%</p>
                            <progress value={course.progress} max="100"></progress>
                            {!course.completed && (
                               <button onClick={() => handleMarkAsCompleted(course.id)}>
                            Mark as Completed
                        </button>
              )}
                    </div>
          </li >
        ))}
        </ul >
    </div >
  );
};

export default UserDashboard;